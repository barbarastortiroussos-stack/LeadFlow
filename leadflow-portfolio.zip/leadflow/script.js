(() => {
  "use strict";

  const STORAGE_KEY = "leadflow_demo_leads_v1";
  const MAX_RECORDS = 250;
  const $ = (selector) => document.querySelector(selector);

  const form = $("#leadForm");
  const runButton = $("#runButton");
  const execution = $("#execution");
  const resultCard = $("#resultCard");
  const toast = $("#toast");
  const leadsTableBody = $("#leadsTableBody");
  const searchInput = $("#searchInput");
  const clearDialog = $("#clearDialog");

  let leads = loadLeads();
  let activeRun = false;
  let toastTimer;

  function loadLeads() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(saved) ? saved.filter(isValidStoredLead).slice(0, MAX_RECORDS) : [];
    } catch (error) {
      console.warn("Não foi possível ler o histórico local.", error);
      return [];
    }
  }

  function isValidStoredLead(lead) {
    return lead && typeof lead.id === "string" &&
      typeof lead.name === "string" && typeof lead.email === "string" &&
      typeof lead.service === "string" && typeof lead.priority === "string" &&
      typeof lead.createdAt === "string";
  }

  function saveLeads() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(leads.slice(0, MAX_RECORDS)));
      return true;
    } catch (error) {
      console.warn("Não foi possível salvar o histórico local.", error);
      showToast("O navegador não permitiu salvar o histórico. A execução ainda foi concluída.", true);
      return false;
    }
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function initials(name) {
    return String(name).trim().split(/\s+/).slice(0, 2).map(part => part.charAt(0)).join("").toUpperCase();
  }

  function formatCurrency(value) {
    const labels = {
      unknown: "Não definido",
      low: "Até R$ 500",
      mid: "R$ 501–2.000",
      high: "R$ 2.001–5.000",
      premium: "Acima de R$ 5.000"
    };
    return labels[value] || "Não definido";
  }

  function formatDate(isoString) {
    const date = new Date(isoString);
    if (Number.isNaN(date.getTime())) return "—";
    return new Intl.DateTimeFormat("pt-BR", {
      day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"
    }).format(date).replace(" de ", " ");
  }

  function showToast(message, isError = false) {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.toggle("error", isError);
    toast.classList.add("show");
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3600);
  }

  function getFormData() {
    return {
      name: $("#name").value.trim(),
      email: $("#email").value.trim(),
      company: $("#company").value.trim(),
      service: $("#service").value,
      budget: $("#budget").value
    };
  }

  function clearErrors() {
    document.querySelectorAll(".field-error").forEach(el => { el.textContent = ""; });
    document.querySelectorAll(".field input, .field select").forEach(el => el.classList.remove("invalid"));
  }

  function setError(fieldId, message) {
    const input = $("#" + fieldId);
    const error = $("#" + fieldId + "Error");
    if (input) input.classList.add("invalid");
    if (error) error.textContent = message;
  }

  function validate(data) {
    clearErrors();
    let valid = true;

    if (data.name.length < 2) {
      setError("name", "Informe um nome com pelo menos 2 caracteres.");
      valid = false;
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    if (!emailPattern.test(data.email)) {
      setError("email", "Informe um e-mail em formato válido.");
      valid = false;
    }
    if (!data.service) {
      setError("service", "Selecione um serviço de interesse.");
      valid = false;
    }
    if (!["unknown", "low", "mid", "high", "premium"].includes(data.budget)) {
      data.budget = "unknown";
    }
    return valid;
  }

  function classifyLead(data) {
    // Regra de negócio demonstrativa baseada no orçamento selecionado.
    const scores = { unknown: 10, low: 20, mid: 55, high: 80, premium: 95 };
    const score = scores[data.budget] ?? 10;

    if (data.budget === "high" || data.budget === "premium") {
      return {
        priority: "high",
        priorityLabel: "Alta prioridade",
        score,
        explanation: "O orçamento informado sugere uma oportunidade de maior valor. Vale priorizar uma conversa para entender escopo, prazo e necessidades.",
        nextAction: "Recomendar contato prioritário e agendamento de uma conversa de descoberta."
      };
    }
    if (data.budget === "mid") {
      return {
        priority: "medium",
        priorityLabel: "Em acompanhamento",
        score,
        explanation: "O orçamento está em uma faixa intermediária. Uma conversa de qualificação pode ajudar a confirmar o escopo e a aderência da solução.",
        nextAction: "Recomendar acompanhamento e envio de informações relevantes sobre o serviço."
      };
    }
    return {
      priority: "nurture",
      priorityLabel: "Nutrição",
      score,
      explanation: data.budget === "low"
        ? "O orçamento informado é inicial. Pode ser útil entender as prioridades do lead e avaliar uma opção de escopo reduzido."
        : "O orçamento ainda não foi definido. É recomendável compreender a necessidade antes de estimar uma solução.",
      nextAction: "Recomendar uma conversa inicial ou conteúdo educativo, sem pressionar por uma compra."
    };
  }

  const wait = (ms) => new Promise(resolve => window.setTimeout(resolve, ms));

  function setStep(stepId, state, statusText) {
    const step = $("#" + stepId);
    if (!step) return;
    step.classList.remove("running", "done");
    if (state) step.classList.add(state);
    step.querySelector(".workflow-state").textContent = statusText;
  }

  function resetSteps() {
    setStep("stepValidate", "", "Aguardando");
    setStep("stepClassify", "", "Aguardando");
    setStep("stepAction", "", "Aguardando");
  }

  async function runAutomation(data) {
    if (activeRun) return;
    activeRun = true;
    runButton.disabled = true;
    runButton.innerHTML = '<span class="button-spark">◌</span> Executando...';
    execution.hidden = false;
    resultCard.hidden = true;
    resetSteps();
    $("#executionTitle").textContent = "Processando lead...";
    $("#executionBadge").textContent = "EM ANDAMENTO";
    $("#executionBadge").classList.add("running");
    $("#flowStatus").textContent = "Automação em execução";

    try {
      setStep("stepValidate", "running", "Verificando...");
      await wait(450);
      setStep("stepValidate", "done", "Concluído");

      setStep("stepClassify", "running", "Analisando...");
      await wait(650);
      const classification = classifyLead(data);
      setStep("stepClassify", "done", "Concluído");

      setStep("stepAction", "running", "Preparando...");
      await wait(450);

      const lead = {
        id: createId(),
        ...data,
        ...classification,
        createdAt: new Date().toISOString()
      };

      leads.unshift(lead);
      leads = leads.slice(0, MAX_RECORDS);
      saveLeads();
      renderAll();

      setStep("stepAction", "done", "Concluído");
      $("#executionTitle").textContent = "Execução concluída";
      $("#executionBadge").textContent = "CONCLUÍDO";
      $("#executionBadge").classList.remove("running");
      $("#flowStatus").textContent = "Última execução concluída";
      renderResult(lead);
      showToast("Lead processado e classificado com sucesso.");
    } catch (error) {
      console.error("Erro na demonstração:", error);
      $("#executionTitle").textContent = "Não foi possível concluir";
      $("#executionBadge").textContent = "ERRO";
      $("#executionBadge").classList.remove("running");
      $("#flowStatus").textContent = "Ocorreu um erro na execução";
      showToast("Ocorreu um erro inesperado na demonstração.", true);
    } finally {
      activeRun = false;
      runButton.disabled = false;
      runButton.innerHTML = '<span class="button-spark">✳</span> Executar automação <span class="button-arrow">→</span>';
    }
  }

  function createId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return "lead-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
  }

  function renderResult(lead) {
    const priorityClass = lead.priority === "high" ? "priority-high" :
      lead.priority === "medium" ? "priority-medium" : "priority-nurture";
    resultCard.innerHTML = `
      <div class="result-top">
        <span class="result-icon">✳</span>
        <strong>Resultado da classificação</strong>
        <span class="priority-badge ${priorityClass}">${escapeHTML(lead.priorityLabel)}</span>
      </div>
      <p>${escapeHTML(lead.explanation)}</p>
      <div class="result-action"><span>↗</span><div><strong>Próxima ação sugerida</strong><br>${escapeHTML(lead.nextAction)}</div></div>
    `;
    resultCard.hidden = false;
  }

  function renderMetrics() {
    const total = leads.length;
    const high = leads.filter(lead => lead.priority === "high").length;
    const follow = leads.filter(lead => lead.priority === "medium").length;
    $("#metricTotal").textContent = total;
    $("#metricHigh").textContent = high;
    $("#metricFollow").textContent = follow;
    $("#metricRuns").innerHTML = `${total}<span class="value-suffix">/100%</span>`;
    $("#navLeadCount").textContent = total;
    $("#tableCount").textContent = total;
  }

  function renderTable() {
    const query = searchInput.value.trim().toLocaleLowerCase("pt-BR");
    const filtered = leads.filter(lead => [
      lead.name, lead.email, lead.company, lead.service, lead.priorityLabel
    ].join(" ").toLocaleLowerCase("pt-BR").includes(query));

    if (filtered.length === 0) {
      const message = leads.length === 0
        ? ["Nenhum lead por enquanto", "Preencha o formulário para ver a automação funcionando."]
        : ["Nenhum resultado encontrado", "Tente buscar por outro nome, e-mail ou serviço."];
      leadsTableBody.innerHTML = `<tr class="empty-row"><td colspan="5"><div class="empty-state"><span class="empty-icon">⌁</span><strong>${message[0]}</strong><p>${message[1]}</p></div></td></tr>`;
    } else {
      leadsTableBody.innerHTML = filtered.map(lead => {
        const priorityClass = lead.priority === "high" ? "priority-high" :
          lead.priority === "medium" ? "priority-medium" : "priority-nurture";
        return `<tr>
          <td><div class="contact-cell"><div class="contact-avatar">${escapeHTML(initials(lead.name))}</div><div class="contact-details"><strong>${escapeHTML(lead.name)}</strong><span>${escapeHTML(lead.email)}</span></div></div></td>
          <td class="service-cell">${escapeHTML(lead.service)}</td>
          <td class="budget-cell">${escapeHTML(formatCurrency(lead.budget))}</td>
          <td><span class="priority-badge ${priorityClass}">${escapeHTML(lead.priorityLabel)}</span></td>
          <td class="date-cell">${escapeHTML(formatDate(lead.createdAt))}</td>
        </tr>`;
      }).join("");
    }

    $("#tableSummary").textContent = `Mostrando ${filtered.length} de ${leads.length} registro${leads.length === 1 ? "" : "s"}`;
  }

  function renderAll() {
    renderMetrics();
    renderTable();
  }

  function fillSample() {
    const examples = [
      { name: "Alex Martins", email: "alex@exemplo.com", company: "Aurora Studio", service: "Criação de site", budget: "premium" },
      { name: "Camila Rocha", email: "camila@exemplo.com", company: "Ponto Criativo", service: "Marketing digital", budget: "mid" },
      { name: "Rafa Oliveira", email: "rafa@exemplo.com", company: "Projeto pessoal", service: "Automação de processos", budget: "unknown" }
    ];
    const current = getFormData();
    const next = examples[Math.floor(Math.random() * examples.length)];
    $("#name").value = next.name;
    $("#email").value = next.email;
    $("#company").value = next.company;
    $("#service").value = next.service;
    $("#budget").value = next.budget;
    clearErrors();
    showToast("Exemplo fictício preenchido. Clique em executar para testar.");
  }

  function exportCSV() {
    if (leads.length === 0) {
      showToast("Ainda não há leads para exportar.", true);
      return;
    }
    const columns = [
      ["Nome", "name"], ["E-mail", "email"], ["Empresa", "company"],
      ["Serviço", "service"], ["Orçamento", "budget"], ["Prioridade", "priorityLabel"],
      ["Pontuação demonstrativa", "score"], ["Data", "createdAt"]
    ];
    const csvEscape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const rows = [columns.map(([label]) => csvEscape(label)).join(";")];
    leads.forEach(lead => rows.push(columns.map(([, key]) => csvEscape(
      key === "budget" ? formatCurrency(lead[key]) : lead[key]
    )).join(";")));
    const blob = new Blob(["\uFEFF" + rows.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "leadflow-historico.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Arquivo CSV preparado para exportação.");
  }

  function clearHistory() {
    leads = [];
    saveLeads();
    renderAll();
    resultCard.hidden = true;
    execution.hidden = true;
    $("#flowStatus").textContent = "Histórico limpo — aguardando nova execução";
    clearDialog.close();
    showToast("Histórico local removido.");
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (activeRun) return;
    const data = getFormData();
    if (!validate(data)) {
      showToast("Confira os campos destacados antes de continuar.", true);
      const firstInvalid = document.querySelector(".field input.invalid, .field select.invalid");
      if (firstInvalid) firstInvalid.focus();
      return;
    }
    await runAutomation(data);
  });

  $("#sampleButton").addEventListener("click", fillSample);
  $("#exportButton").addEventListener("click", exportCSV);
  searchInput.addEventListener("input", renderTable);
  $("#clearButton").addEventListener("click", () => {
    if (leads.length === 0) {
      showToast("O histórico já está vazio.");
      return;
    }
    if (typeof clearDialog.showModal === "function") clearDialog.showModal();
    else if (window.confirm("Deseja limpar o histórico local?")) clearHistory();
  });
  $("#cancelClear").addEventListener("click", () => clearDialog.close());
  $("#confirmClear").addEventListener("click", clearHistory);
  clearDialog.addEventListener("click", (event) => {
    if (event.target === clearDialog) clearDialog.close();
  });

  const mobileMenu = $("#mobileMenu");
  const sidebar = $("#sidebar");
  mobileMenu.addEventListener("click", () => {
    const isOpen = sidebar.classList.toggle("open");
    mobileMenu.setAttribute("aria-expanded", String(isOpen));
    mobileMenu.setAttribute("aria-label", isOpen ? "Fechar menu" : "Abrir menu");
  });
  sidebar.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    sidebar.classList.remove("open");
    mobileMenu.setAttribute("aria-expanded", "false");
    mobileMenu.setAttribute("aria-label", "Abrir menu");
  }));

  renderAll();
})(); 
