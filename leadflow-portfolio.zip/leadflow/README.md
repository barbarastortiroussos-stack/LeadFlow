# LeadFlow — Interactive Lead Automation Demo

Demonstração de portfólio feita com HTML, CSS e JavaScript puro.

## Executar localmente
1. Baixe ou extraia os arquivos.
2. Abra `index.html` no navegador. Não é necessário instalar dependências.
3. Clique em **Preencher exemplo** e depois em **Executar automação**.

Para uma experiência de desenvolvimento, você também pode abrir a pasta no VS Code e usar a extensão Live Server.

## Publicar no GitHub Pages
1. Crie um repositório público chamado `leadflow` (ou outro nome).
2. Envie `index.html`, `style.css` e `script.js` para a raiz do repositório.
3. No GitHub, entre em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)`, e clique em **Save**.
6. Aguarde a publicação. O GitHub exibirá o endereço público na mesma seção.

## O que a demo faz
- Valida nome, e-mail e serviço.
- Classifica o lead usando regras demonstrativas baseadas no orçamento.
- Anima as etapas de validação, classificação e recomendação.
- Mostra métricas e histórico de execuções.
- Salva os registros em `localStorage` no navegador atual.
- Permite pesquisar o histórico, exportar CSV e limpar registros.

## Limitações intencionais
- Não envia e-mails, mensagens de WhatsApp nem dados a terceiros.
- Não existe backend nem banco de dados compartilhado.
- O histórico é local ao navegador/dispositivo e pode ser apagado pelo usuário.
- A pontuação e as prioridades são regras ilustrativas, não uma previsão real de conversão.
- Dados inseridos não devem ser informações pessoais reais.

## Próximas evoluções
1. Criar backend e banco de dados.
2. Implementar autenticação e controle de acesso.
3. Integrar CRM e serviços de comunicação com consentimento e tratamento adequado de dados.
4. Configurar regras de classificação por cliente.
